using WinterPreparation;

namespace Tests;

public class TestsData
{
    public static string[] box1 = { "apple", "worm", "banana", "worm", "carrot", "pear" };
    public static string[] box2 = { "apple", "banana", "carrot" };
    public static string[] box3 = { "worm", "worm" };
    public static string[] box4 = { "apple", "apricot", "ambarella", "amla", "avocado" };
    public static string[] box5 = {  };
    
    public static string[] box6 = { "apple", "banana", "ladybug", "pear", "cucumber", "worm", "almond", "cashew", "ladybug" };
    public static string[] box7 = { "ladybug" };
    public static string[] box8 = { "pineapple", "papaya", "pitaya", "peach", "passion fruit", "pear" };
    
    public static string[] fruitCategory = { "apple", "banana", "pear" };
    public static string[] vegetableCategory = { "carrot", "cucumber", "potato" };
    public static string[] nutCategory = { "almond", "cashew", "walnut" };
    
    public static List<Smurf> smurfsList1 = new List<Smurf>
    {
        new Smurf("Poet Smurf", "Scribe", "Worker", 37),
        new Smurf("Hefty Smurf", "Farmer", "Worker", 68),
        new Smurf("Doctor Smurf", "Cook", "Deputy Captain", 42),
        new Smurf("Baker Smurf", "Cook", "Worker", 18),
        new Smurf("Brainy Smurf", "Scribe", "Worker", 4),
        new Smurf("Grouchy Smurf", "Miner", "Worker", 33),
        new Smurf("Vanity Smurf", "Builder", "Worker", 76),
        new Smurf("Smurfette", "Cook", "Captain", 24),
        new Smurf("Clumsy Smurf", "Builder", "Worker", 26),
        new Smurf("Handy Smurf", "Builder", "Worker", 42),
        new Smurf("Dreamy Smurf", "Cook", "Worker", 26),
        new Smurf("Fisher Smurf", "Harvester", "Worker", 48),
        new Smurf("Tailor Smurf", "Scribe", "Worker", 29),
        new Smurf("Grandpa Smurf", "Miner", "Worker", 29),
        new Smurf("Farmer Smurf", "Farmer", "Worker", 101),
        new Smurf("Energetic Smurf", "Builder", "Worker", 74),
        new Smurf("Greedy Smurf", "Harvester", "Worker", 19),
        new Smurf("Jokey Smurf", "Scribe", "Worker", 122),
        new Smurf("Harmony Smurf", "Scribe", "Worker", 19),
        new Smurf("Inventor Smurf", "Scribe", "Worker", 8),
        new Smurf("Nimble Smurf", "Miner", "Worker", 46),
        new Smurf("Brave Smurf", "Farmer", "Worker", 54)
    };
    
    public static  List<Smurf> smurfsList2 = new List<Smurf>
    {
        new Smurf("Adventure Smurf", "Scribe", "Worker", 5),
        new Smurf("Brave Smurf", "Farmer", "Worker", 70),
        new Smurf("Energetic Smurf", "Cook", "Deputy Captain", 30),
        new Smurf("Friendly Smurf", "Cook", "Worker", 25),
        new Smurf("Curious Smurf", "Scribe", "Worker", 40),
        new Smurf("Dancer Smurf", "Miner", "Worker", 20),
        new Smurf("Jolly Smurf", "Builder", "Worker", 78),
        new Smurf("Happy Smurf", "Cook", "Captain", 42),
        new Smurf("Inventor Smurf", "Builder", "Worker", 67),
        new Smurf("Nimble Smurf", "Builder", "Worker", 43),
        new Smurf("Quick Smurf", "Cook", "Worker", 27),
        new Smurf("Radiant Smurf", "Harvester", "Worker", 52),
        new Smurf("Kind Smurf", "Scribe", "Worker", 31),
        new Smurf("Peaceful Smurf", "Harvester", "Worker", 29),
        new Smurf("Mighty Smurf", "Farmer", "Worker", 105),
        new Smurf("Silly Smurf", "Builder", "Worker", 70),
        new Smurf("Thoughtful Smurf", "Hunter", "Worker", 21),
        new Smurf("Valiant Smurf", "Harvester", "Worker", 61),
        new Smurf("Wise Smurf", "Scribe", "Worker", 124),
        new Smurf("Lucky Smurf", "Scribe", "Worker", 17),
        new Smurf("Optimistic Smurf", "Scribe", "Worker", 10),
        new Smurf("Unique Smurf", "Scribe", "Worker", 87),
        new Smurf("Bashful Smurf", "Harvester", "Worker", 44),
        new Smurf("Radiant Smurf", "Farmer", "Worker", 56)
    };
    
    public static List<Smurf> smurfsList3 = new List<Smurf>
    {
        new Smurf("Cheery Smurf", "Cook", "Worker", 23),
        new Smurf("Mellow Smurf", "Gardener", "Worker", 45),
        new Smurf("Lucky Smurf", "Hunter", "Worker", 32),
        new Smurf("Wise Smurf", "Sage", "Captain", 88),
        new Smurf("Jovial Smurf", "Entertainer", "Worker", 29),
        new Smurf("Eager Smurf", "Explorer", "Worker", 19),
        new Smurf("Nifty Smurf", "Craftsman", "Worker", 57),
        new Smurf("Sage Smurf", "Philosopher", "Worker", 65),
        new Smurf("Zippy Smurf", "Runner", "Worker", 20),
        new Smurf("Snappy Smurf", "Photographer", "Worker", 30),
        new Smurf("Ponder Smurf", "Thinker", "Worker", 54),
        new Smurf("Jolly Smurf", "Musician", "Worker", 40),
        new Smurf("Gleeful Smurf", "Singer", "Worker", 22),
        new Smurf("Sprightly Smurf", "Dancer", "Worker", 26),
        new Smurf("Lively Smurf", "Athlete", "Worker", 18),
        new Smurf("Sunny Smurf", "Farmer", "Deputy Captain", 67),
        new Smurf("Hearty Smurf", "Cook", "Worker", 36),
        new Smurf("Plucky Smurf", "Adventurer", "Deputy Captain", 31),
        new Smurf("Chipper Smurf", "Builder", "Worker", 25),
        new Smurf("Peppy Smurf", "Harvester", "Worker", 43)
    };
    
    public static Market market1 = new Market(
        new List<Transaction>()
        {
            new Transaction("Hefty Smurf", "Apples", 10, new DateTime(2021, 3, 30)),
            new Transaction("Hefty Smurf", "Carrots", 10, new DateTime(2021, 3, 30)),
            new Transaction("Hefty Smurf", "Potatoes", 5, new DateTime(2020, 9, 8)),
            new Transaction("Brainy Smurf", "Apples", 14, new DateTime(2020, 7, 1)),
            new Transaction("Papa Smurf", "Potatoes", 4, new DateTime(2020, 12, 12)),
            new Transaction("Papa Smurf", "Apples", 26, new DateTime(2019, 11, 15)),
            new Transaction("Hefty Smurf", "Potatoes", 42, new DateTime(2019, 5, 6)),
            new Transaction("Brainy Smurf", "Apples", 9, new DateTime(2019, 3, 7)),
            new Transaction("Papa Smurf", "Potatoes", 19, new DateTime(2019, 8, 8)),
        },
        new List<Smurf>() {
            new Smurf("Papa Smurf", "Alchemist", "Worker", 215),
            new Smurf("Smurfette", "Farmer", "Worker", 26),
            new Smurf("Brainy Smurf", "Scriber", "Worker", 72),
            new Smurf("Hefty Smurf", "Blacksmith", "Worker", 48),
            new Smurf("Clumsy Smurf", "Builder", "Worker", 16),
        }
    );
    
    public static Market market2 = new Market(
        new List<Transaction>()
        {
            new Transaction("Inventor Smurf", "Bread", 10, new DateTime(2021, 3, 30)),
            new Transaction("Inventor Smurf", "Cake", 10, new DateTime(2021, 3, 30)),
            new Transaction("Inventor Smurf", "Croissant", 5, new DateTime(2020, 9, 8)),
            new Transaction("Clumsy Smurf", "Cake", 14, new DateTime(2020, 7, 1)),
            new Transaction("Papa Smurf", "Bread", 4, new DateTime(2020, 12, 12)),
            new Transaction("Papa Smurf", "Croissant", 26, new DateTime(2019, 11, 15)),
            new Transaction("Inventor Smurf", "Croissant", 42, new DateTime(2019, 5, 6)),
            new Transaction("Clumsy Smurf", "Cake", 9, new DateTime(2019, 3, 7)),
            new Transaction("Papa Smurf", "Bread", 19, new DateTime(2019, 8, 8)),
            new Transaction("Smurfette", "Bread", 19, new DateTime(2019, 8, 2)),
        },
        new List<Smurf>() {
            new Smurf("Papa Smurf", "Alchemist", "Worker", 215),
            new Smurf("Smurfette", "Farmer", "Worker", 26),
            new Smurf("Brainy Smurf", "Scriber", "Worker", 72),
            new Smurf("Inventor Smurf", "Blacksmith", "Worker", 48),
            new Smurf("Clumsy Smurf", "Builder", "Worker", 16),
        }
    );
    
    public static Market market3 = new Market(
        new List<Transaction>()
        {
            
        },
        new List<Smurf>() {
            new Smurf("Papa Smurf", "Alchemist", "Worker", 215),
            new Smurf("Smurfette", "Farmer", "Worker", 26),
            new Smurf("Brainy Smurf", "Scriber", "Worker", 72),
            new Smurf("Inventor Smurf", "Blacksmith", "Worker", 48),
            new Smurf("Clumsy Smurf", "Builder", "Worker", 16),
        }
    );

    public static bool IsSmurfEqual(Smurf? expected, Smurf? actual)
    {
        if (expected == null && actual == null)
        {
            return true;
        }
        if (expected == null || actual == null)
        {
            return false;
        }
        return expected.Name == actual.Name && expected.Job == actual.Job && expected.Rank == actual.Rank && expected.Age == actual.Age;
    }
    
    public static bool IsSmurfListEqual(List<Smurf> expected, List<Smurf> actual)
    {
        if (expected.Count != actual.Count)
        {
            return false;
        }
        for (int i = 0; i < expected.Count; i++)
        {
            if (!IsSmurfEqual(expected[i], actual[i]))
            {
                return false;
            }
        }
        return true;
    }

}