using WinterPreparation;

namespace Tests.CoreTests;

public class GetWormPercentageTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestSampleBox1()
    {
        var box = TestsData.box1;
        var actual = FirstParchment.GetWormPercentage(box);
        Assert.That(actual is < 33.334 and > 33.332);
    }
    
    [Test]
    public void TestSampleBox2()
    {
        var box = TestsData.box6;
        var actual = FirstParchment.GetWormPercentage(box);
        Console.WriteLine(actual);
        Assert.That(actual is < 11.112 and > 11.110);
    }
    
    [Test]
    public void TestWithoutBugBox1()
    {
        var box = TestsData.box2;
        var actual = FirstParchment.GetWormPercentage(box);
        Assert.That(actual is < 0.001 and > -0.001);
    }
    
    
    [Test]
    public void TestEmptyBox1()
    {
        var box = TestsData.box5;
        Assert.Catch<ArgumentException>(() => FirstParchment.GetWormPercentage(box));
    }
}