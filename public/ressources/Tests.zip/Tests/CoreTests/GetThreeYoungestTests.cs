using WinterPreparation;

namespace Tests.CoreTests;

public class GetThreeYoungestTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestSampleList1()
    {
        var expected = new List<Smurf>
        {
            new Smurf("Brainy Smurf", "Scribe", "Worker", 4),
            new Smurf("Inventor Smurf", "Scribe", "Worker", 8),
            new Smurf("Baker Smurf", "Cook", "Worker", 18),
        };
        
        var smurfsList1 = TestsData.smurfsList1;
        var actual = Smurf.GetThreeYoungest(smurfsList1);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList2()
    {
        var expected = new List<Smurf>
        {
            new Smurf("Adventure Smurf", "Scribe", "Worker", 5),
            new Smurf("Optimistic Smurf", "Scribe", "Worker", 10),
            new Smurf("Lucky Smurf", "Scribe", "Worker", 17),
        };
        
        var smurfsList2 = TestsData.smurfsList2;
        var actual = Smurf.GetThreeYoungest(smurfsList2);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList3()
    {
        var expected = new List<Smurf>
        {
            new Smurf("Lively Smurf", "Athlete", "Worker", 18),
            new Smurf("Eager Smurf", "Explorer", "Worker", 19),
            new Smurf("Zippy Smurf", "Runner", "Worker", 20),
        };
        
        var smurfsList3 = TestsData.smurfsList3;
        var actual = Smurf.GetThreeYoungest(smurfsList3);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestMiniList()
    {
        var expected = new List<Smurf>
        {
            new Smurf("Brainy Smurf", "Scribe", "Worker", 4),
            new Smurf("Jokey Smurf", "Scribe", "Worker", 8),
        };
        
        var smurfsList = new List<Smurf>
        {
            new Smurf("Brainy Smurf", "Scribe", "Worker", 4),
            new Smurf("Jokey Smurf", "Scribe", "Worker", 8),
        };
        var actual = Smurf.GetThreeYoungest(smurfsList);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestEmptyList()
    {
        var expected = new List<Smurf>();
        
        var smurfsList = new List<Smurf>();
        var actual = Smurf.GetThreeYoungest(smurfsList);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
}