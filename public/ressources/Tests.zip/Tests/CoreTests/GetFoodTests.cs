using WinterPreparation;

namespace Tests.CoreTests;

public class GetFoodTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestSampleBox1()
    {
        var box = TestsData.box1;
        var expected = new List<string> { "apple", "banana", "carrot", "pear" };
        var actual = FirstParchment.GetFood(box, "worm").ToList();
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestSampleBox2()
    {
        var box = TestsData.box6;
        var expected = new List<string> { "apple", "banana", "pear", "cucumber", "worm", "almond", "cashew" };;
        var actual = FirstParchment.GetFood(box, "ladybug").ToList();
    }
    
    [Test]
    public void TestWithoutBugBox1()
    {
        var box = TestsData.box2;
        var expected = new List<string>() { "apple", "banana", "carrot" };
        var actual = FirstParchment.GetFood(box, "worm").ToList();
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestWithoutGoodBugBox1()
    {
        var box = TestsData.box3;
        var expected = new List<string> { "worm", "worm" };
        var actual = FirstParchment.GetFood(box, "ladybug").ToList();
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestEmptyBox1()
    {
        var box = TestsData.box5;
        var expected = new List<string> { };
        var actual = FirstParchment.GetFood(box, "ladybug").ToList();
        Assert.That(actual, Is.EqualTo(expected));
    }
}