using WinterPreparation;

namespace Tests.CoreTests;

public class GetRankAverageAgeTests
{
    [SetUp]
    public void Setup()
    {
    }
    
    [Test]
    public void TestSampleList1()
    {
        List<Smurf> smurfsList = TestsData.smurfsList1;
        string rank = "Worker";
        
        double expected = 44;
        
        double actual = Smurf.GetRankAverageAge(smurfsList, rank);
        Assert.That(Math.Abs(actual - expected) < 0.1);
    }
    
    [Test]
    public void TestSampleList2()
    {
        List<Smurf> smurfsList = TestsData.smurfsList2;
        string rank = "Deputy Captain";
        
        double expected = 30;
        
        double actual = Smurf.GetRankAverageAge(smurfsList, rank);
        Assert.That(Math.Abs(actual - expected) < 0.1);
    }
    
    [Test]
    public void TestSampleList3()
    {
        List<Smurf> smurfsList = TestsData.smurfsList3;
        string rank = "Worker";
        
        double expected = 34.4;
        
        double actual = Smurf.GetRankAverageAge(smurfsList, rank);
        Assert.That(Math.Abs(actual - expected) < 0.1);
    }
}