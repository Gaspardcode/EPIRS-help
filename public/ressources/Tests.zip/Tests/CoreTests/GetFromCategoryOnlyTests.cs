using WinterPreparation;
using System.Collections.Generic;

namespace Tests.CoreTests;

public class GetFromCategoryOnlyTests
{
    [SetUp]
    public void Setup()
    {
    }
    
    [Test]
    public void TestSampleBox1()
    {
        var box = TestsData.box1;
        var category = TestsData.fruitCategory;
        var expected = new List<string> { "apple", "banana", "pear" };
        var actual = FirstParchment.GetFromCategoryOnly(box, category);
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestSampleBox2()
    {
        var box = TestsData.box6;
        var category = TestsData.nutCategory;
        var expected = new List<string> { "almond", "cashew" };
        var actual = FirstParchment.GetFromCategoryOnly(box, category);
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestWithoutCategoryBox1()
    {
        var box = TestsData.box2;
        var category = TestsData.nutCategory;
        var expected = new List<string> { };
        var actual = FirstParchment.GetFromCategoryOnly(box, category);
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestEmptyBox1()
    {
        var box = TestsData.box5;
        var category = TestsData.fruitCategory;
        var expected = new List<string> { };
        var actual = FirstParchment.GetFromCategoryOnly(box, category);
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestEmptyCategoryBox1()
    {
        var box = TestsData.box1;
        var category = new string[] { };
        var expected = new List<string> { };
        var actual = FirstParchment.GetFromCategoryOnly(box, category);
        Assert.That(actual, Is.EqualTo(expected));
    }
}