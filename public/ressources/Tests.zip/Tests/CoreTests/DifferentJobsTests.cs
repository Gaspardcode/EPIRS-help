using WinterPreparation;

namespace Tests.CoreTests;

public class DifferentJobsTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestSampleList1()
    {
        var smurfsList = TestsData.smurfsList1;
        var actual = Smurf.DifferentJobs(smurfsList);

        var expected = 6;
        
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestSampleList2()
    {
        var smurfsList = TestsData.smurfsList2;
        var actual = Smurf.DifferentJobs(smurfsList);
        Console.WriteLine(actual);

        var expected = 7;
        
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestSampleList3()
    {
        var smurfsList = new List<Smurf>()
        {
            new Smurf("Adventure Smurf", "Scribe", "Worker", 5),
            new Smurf("Brave Smurf", "Farmer", "Worker", 70),
            new Smurf("Energetic Smurf", "Scribe", "Deputy Captain", 30),
            new Smurf("Friendly Smurf", "Scribe", "Worker", 25),
        };
        var actual = Smurf.DifferentJobs(smurfsList);
        var expected = 2;
        
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestEmptyList()
    {
        var smurfsList = new List<Smurf>();
        var actual = Smurf.DifferentJobs(smurfsList);

        var expected = 0;
        
        Assert.That(actual, Is.EqualTo(expected));
    }
}