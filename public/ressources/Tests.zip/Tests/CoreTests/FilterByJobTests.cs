using WinterPreparation;

namespace Tests.CoreTests;

public class FilterByJobTests
{
    [SetUp]
    public void Setup()
    {
    }
    
    [Test]
    public void TestSampleList1()
    {
        var smurfsList = TestsData.smurfsList1;
        var job = "Cook";
        
        var expected = new List<Smurf>
        {
            new Smurf("Doctor Smurf", "Cook", "Deputy Captain", 42),
            new Smurf("Baker Smurf", "Cook", "Worker", 18),
            new Smurf("Smurfette", "Cook", "Captain", 24),
            new Smurf("Dreamy Smurf", "Cook", "Worker", 26),
        };
        
        var actual = Smurf.FilterByJob(smurfsList, job);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList2()
    {
        var smurfsList = TestsData.smurfsList2;
        var job = "Scribe";
        
        var expected = new List<Smurf>
        {
            new Smurf("Adventure Smurf", "Scribe", "Worker", 5),
            new Smurf("Curious Smurf", "Scribe", "Worker", 40),
            new Smurf("Kind Smurf", "Scribe", "Worker", 31),
            new Smurf("Wise Smurf", "Scribe", "Worker", 124),
            new Smurf("Lucky Smurf", "Scribe", "Worker", 17),
            new Smurf("Optimistic Smurf", "Scribe", "Worker", 10),
            new Smurf("Unique Smurf", "Scribe", "Worker", 87),
        };
        
        var actual = Smurf.FilterByJob(smurfsList, job);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList3()
    {
        var smurfsList = TestsData.smurfsList3;
        var job = "Cook";
        
        var expected = new List<Smurf>
        {
            new Smurf("Cheery Smurf", "Cook", "Worker", 23),
            new Smurf("Hearty Smurf", "Cook", "Worker", 36),
        };
        
        var actual = Smurf.FilterByJob(smurfsList, job);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestNotFound()
    {
        var smurfsList = TestsData.smurfsList3;
        var job = "Teacher";
        
        var expected = new List<Smurf>();
        
        var actual = Smurf.FilterByJob(smurfsList, job);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestEmptyList()
    {
        var smurfsList = new List<Smurf>();
        var job = "Cook";
        
        var expected = new List<Smurf>();
        
        var actual = Smurf.FilterByJob(smurfsList, job);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
}