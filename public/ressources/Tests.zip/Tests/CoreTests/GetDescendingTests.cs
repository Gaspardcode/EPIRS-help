using WinterPreparation;

namespace Tests.CoreTests;

public class GetDescendingTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestOneLayerSorting1()
    {
        var box = TestsData.box1;
        List<string> expected = new List<string>(){ "worm", "worm", "pear", "carrot", "banana", "apple" };
        IEnumerable<string> actual = FirstParchment.GetDescending(box).ToList();
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void TestOneLayerSorting2()
    {
        var box = TestsData.box6;
        List<string> expected = new List<string>(){  "worm", "pear", "ladybug", "ladybug", "cucumber", "cashew", "banana", "apple", "almond", };
        IEnumerable<string> actual = FirstParchment.GetDescending(box).ToList();
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestMultipleLayerSorting1()
    {
        var box = TestsData.box4;
        List<string> expected = new List<string>(){ "avocado", "apricot", "apple", "amla", "ambarella", };
        IEnumerable<string> actual = FirstParchment.GetDescending(box).ToList();
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestMultipleLayerSorting2()
    {
        var box = TestsData.box8;
        List<string> expected = new List<string>(){ "pitaya", "pineapple", "pear", "peach", "passion fruit", "papaya", };
        IEnumerable<string> actual = FirstParchment.GetDescending(box).ToList();
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestEmptyBox()
    {
        var box = TestsData.box5;
        List<string> expected = new List<string>(){ };
        IEnumerable<string> actual = FirstParchment.GetDescending(box).ToList();
        Assert.That(actual, Is.EqualTo(expected));
    }
}