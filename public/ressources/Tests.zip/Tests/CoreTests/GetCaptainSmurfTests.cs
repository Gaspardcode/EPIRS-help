using WinterPreparation;

namespace Tests.CoreTests;

public class GetCaptainSmurfTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestSampleList1()
    {
        Smurf expected = new Smurf("Smurfette", "Cook", "Captain", 24);
        List<Smurf> smurfsList1 = TestsData.smurfsList1;

        Smurf? actual = Smurf.GetCaptainSmurf(smurfsList1);

        Assert.That(TestsData.IsSmurfEqual(expected, actual));
    }

    [Test]
    public void TestSampleList2()
    {
        Smurf expected = new Smurf("Happy Smurf", "Cook", "Captain", 42);
        List<Smurf> smurfsList2 = TestsData.smurfsList2;

        Smurf? actual = Smurf.GetCaptainSmurf(smurfsList2);

        Assert.That(TestsData.IsSmurfEqual(expected, actual));
    }

    [Test]
    public void TestSampleList3()
    {
        Smurf expected = new Smurf("Wise Smurf", "Sage", "Captain", 88);
        List<Smurf> smurfsList = TestsData.smurfsList3;

        Smurf? actual = Smurf.GetCaptainSmurf(smurfsList);

        Assert.That(TestsData.IsSmurfEqual(expected, actual));
    }

    [Test]
    public void TestWithoutCaptain()
    {
        Smurf expected = null;
        List<Smurf> smurfsList = new List<Smurf>()
        {
            new Smurf("Sprightly Smurf", "Dancer", "Worker", 26),
            new Smurf("Lively Smurf", "Athlete", "Worker", 18),
            new Smurf("Sunny Smurf", "Farmer", "Deputy Captain", 67),
            new Smurf("Hearty Smurf", "Cook", "Worker", 36),
        };
        
        Smurf? actual = Smurf.GetCaptainSmurf(smurfsList);
        
        Assert.That(TestsData.IsSmurfEqual(expected, actual));
    }
    
    [Test]
    public void TestEmptyList()
    {
        Smurf expected = null;
        List<Smurf> smurfsList = new List<Smurf>();
        
        Smurf? actual = Smurf.GetCaptainSmurf(smurfsList);
        
        Assert.That(TestsData.IsSmurfEqual(expected, actual));
    }

}