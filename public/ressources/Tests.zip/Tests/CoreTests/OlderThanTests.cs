using WinterPreparation;

namespace Tests.CoreTests;

public class OlderThanTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestSampleList1()
    {
        var expected = new List<Smurf>
        {
            new Smurf("Hefty Smurf", "Farmer", "Worker", 68),
            new Smurf("Doctor Smurf", "Cook", "Deputy Captain", 42),
            new Smurf("Vanity Smurf", "Builder", "Worker", 76),
            new Smurf("Handy Smurf", "Builder", "Worker", 42),
            new Smurf("Fisher Smurf", "Harvester", "Worker", 48),
            new Smurf("Farmer Smurf", "Farmer", "Worker", 101),
            new Smurf("Energetic Smurf", "Builder", "Worker", 74),
            new Smurf("Jokey Smurf", "Scribe", "Worker", 122),
            new Smurf("Nimble Smurf", "Miner", "Worker", 46),
            new Smurf("Brave Smurf", "Farmer", "Worker", 54)
        };
        
        var smurfsList1 = TestsData.smurfsList1;
        var actual = Smurf.OlderThan(smurfsList1, 38);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList2()
    {
        var expected = new List<Smurf>
        {
            new Smurf("Brave Smurf", "Farmer", "Worker", 70),
            new Smurf("Jolly Smurf", "Builder", "Worker", 78),
            new Smurf("Inventor Smurf", "Builder", "Worker", 67),
            new Smurf("Radiant Smurf", "Harvester", "Worker", 52),
            new Smurf("Mighty Smurf", "Farmer", "Worker", 105),
            new Smurf("Silly Smurf", "Builder", "Worker", 70),
            new Smurf("Valiant Smurf", "Harvester", "Worker", 61),
            new Smurf("Wise Smurf", "Scribe", "Worker", 124),
            new Smurf("Unique Smurf", "Scribe", "Worker", 87),
            new Smurf("Radiant Smurf", "Farmer", "Worker", 56)
        };
        
        var smurfsList2 = TestsData.smurfsList2;
        var actual = Smurf.OlderThan(smurfsList2, 50);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList3()
    {
        var expected = new List<Smurf>
        {
            new Smurf("Wise Smurf", "Sage", "Captain", 88),
            new Smurf("Sage Smurf", "Philosopher", "Worker", 65),
            new Smurf("Sunny Smurf", "Farmer", "Deputy Captain", 67),
        };
        
        var smurfsList3 = TestsData.smurfsList3;
        var actual = Smurf.OlderThan(smurfsList3, 60);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestTooOld()
    {
        var expected = new List<Smurf>();
        
        var smurfsList = TestsData.smurfsList3;
        var actual = Smurf.OlderThan(smurfsList, 122);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestEmptyList()
    {
        var expected = new List<Smurf>();
        
        var smurfsList = new List<Smurf>();
        var actual = Smurf.OlderThan(smurfsList, 10);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
}