using WinterPreparation;

namespace Tests.IntermediateTests;

public class SortSmurfTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestSampleList()
    {
        var smurfsList1 = TestsData.smurfsList1;

        var expected = new List<Smurf>()
        {
            new Smurf("Smurfette", "Cook", "Captain", 24),
            new Smurf("Doctor Smurf", "Cook", "Deputy Captain", 42),
            new Smurf("Brainy Smurf", "Scribe", "Worker", 4),
            new Smurf("Inventor Smurf", "Scribe", "Worker", 8),
            new Smurf("Baker Smurf", "Cook", "Worker", 18),
            new Smurf("Greedy Smurf", "Harvester", "Worker", 19),
            new Smurf("Harmony Smurf", "Scribe", "Worker", 19),
            new Smurf("Clumsy Smurf", "Builder", "Worker", 26),
            new Smurf("Dreamy Smurf", "Cook", "Worker", 26),
            new Smurf("Tailor Smurf", "Scribe", "Worker", 29),
            new Smurf("Grandpa Smurf", "Miner", "Worker", 29),
            new Smurf("Grouchy Smurf", "Miner", "Worker", 33),
            new Smurf("Poet Smurf", "Scribe", "Worker", 37),
            new Smurf("Handy Smurf", "Builder", "Worker", 42),
            new Smurf("Nimble Smurf", "Miner", "Worker", 46),
            new Smurf("Fisher Smurf", "Harvester", "Worker", 48),
            new Smurf("Brave Smurf", "Farmer", "Worker", 54),
            new Smurf("Hefty Smurf", "Farmer", "Worker", 68),
            new Smurf("Energetic Smurf", "Builder", "Worker", 74),
            new Smurf("Vanity Smurf", "Builder", "Worker", 76),
            new Smurf("Farmer Smurf", "Farmer", "Worker", 101),
            new Smurf("Jokey Smurf", "Scribe", "Worker", 122),
        };
        
        var actual = Smurf.SortSmurf(smurfsList1);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList2()
    {
        var smurfsList2 = TestsData.smurfsList2;

        var expected = new List<Smurf>()
        {
            new Smurf("Happy Smurf", "Cook", "Captain", 42),
            new Smurf("Energetic Smurf", "Cook", "Deputy Captain", 30),
            new Smurf("Adventure Smurf", "Scribe", "Worker", 5),
            new Smurf("Optimistic Smurf", "Scribe", "Worker", 10),
            new Smurf("Lucky Smurf", "Scribe", "Worker", 17),
            new Smurf("Dancer Smurf", "Miner", "Worker", 20),
            new Smurf("Thoughtful Smurf", "Hunter", "Worker", 21),
            new Smurf("Friendly Smurf", "Cook", "Worker", 25),
            new Smurf("Quick Smurf", "Cook", "Worker", 27),
            new Smurf("Peaceful Smurf", "Harvester", "Worker", 29),
            new Smurf("Kind Smurf", "Scribe", "Worker", 31),
            new Smurf("Curious Smurf", "Scribe", "Worker", 40),
            new Smurf("Nimble Smurf", "Builder", "Worker", 43),
            new Smurf("Bashful Smurf", "Harvester", "Worker", 44),
            new Smurf("Radiant Smurf", "Harvester", "Worker", 52),
            new Smurf("Radiant Smurf", "Farmer", "Worker", 56),
            new Smurf("Valiant Smurf", "Harvester", "Worker", 61),
            new Smurf("Inventor Smurf", "Builder", "Worker", 67),
            new Smurf("Brave Smurf", "Farmer", "Worker", 70),
            new Smurf("Silly Smurf", "Builder", "Worker", 70),
            new Smurf("Jolly Smurf", "Builder", "Worker", 78),
            new Smurf("Unique Smurf", "Scribe", "Worker", 87),
            new Smurf("Mighty Smurf", "Farmer", "Worker", 105),
            new Smurf("Wise Smurf", "Scribe", "Worker", 124),
        };
        
        var actual = Smurf.SortSmurf(smurfsList2);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList3()
    {
        var smurfsList3 = TestsData.smurfsList3;

        var expected = new List<Smurf>()
        {
            new Smurf("Wise Smurf", "Sage", "Captain", 88),
            new Smurf("Plucky Smurf", "Adventurer", "Deputy Captain", 31),
            new Smurf("Sunny Smurf", "Farmer", "Deputy Captain", 67),
            new Smurf("Lively Smurf", "Athlete", "Worker", 18),
            new Smurf("Eager Smurf", "Explorer", "Worker", 19),
            new Smurf("Zippy Smurf", "Runner", "Worker", 20),
            new Smurf("Gleeful Smurf", "Singer", "Worker", 22),
            new Smurf("Cheery Smurf", "Cook", "Worker", 23),
            new Smurf("Chipper Smurf", "Builder", "Worker", 25),
            new Smurf("Sprightly Smurf", "Dancer", "Worker", 26),
            new Smurf("Jovial Smurf", "Entertainer", "Worker", 29),
            new Smurf("Snappy Smurf", "Photographer", "Worker", 30),
            new Smurf("Lucky Smurf", "Hunter", "Worker", 32),
            new Smurf("Hearty Smurf", "Cook", "Worker", 36),
            new Smurf("Jolly Smurf", "Musician", "Worker", 40),
            new Smurf("Peppy Smurf", "Harvester", "Worker", 43),
            new Smurf("Mellow Smurf", "Gardener", "Worker", 45),
            new Smurf("Ponder Smurf", "Thinker", "Worker", 54),
            new Smurf("Nifty Smurf", "Craftsman", "Worker", 57),
            new Smurf("Sage Smurf", "Philosopher", "Worker", 65),
        };
        
        var actual = Smurf.SortSmurf(smurfsList3);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestEmptyList()
    {
        var smurfsList = new List<Smurf>();

        var expected = new List<Smurf>();
        
        var actual = Smurf.SortSmurf(smurfsList);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
}