using WinterPreparation;

namespace Tests.IntermediateTests;

public class OldestPerJobTests
{
    [SetUp]
    public void Setup()
    {
    }
    
    public bool IsDictionaryEqual(Dictionary<string, Smurf> expected, Dictionary<string, Smurf> actual)
    {
        if (expected.Count != actual.Count)
        {
            return false;
        }
        
        foreach (var key in expected.Keys)
        {
            if (!actual.ContainsKey(key))
            {
                return false;
            }
            
            if (expected[key].Name != actual[key].Name)
            {
                return false;
            }
            
            if (expected[key].Job != actual[key].Job)
            {
                return false;
            }
            
            if (expected[key].Rank != actual[key].Rank)
            {
                return false;
            }
            
            if (expected[key].Age != actual[key].Age)
            {
                return false;
            }
        }
        
        return true;
    }

    [Test]
    public void TestSampleList1()
    {
        List<Smurf> smurfsList1 = TestsData.smurfsList1;
        
        var expected = new Dictionary<string, Smurf>
        {
            { "Scribe", new Smurf("Jokey Smurf", "Scribe", "Worker", 122) },
            { "Farmer", new Smurf("Farmer Smurf", "Farmer", "Worker", 101) },
            { "Cook", new Smurf("Doctor Smurf", "Cook", "Deputy Captain", 42) },
            { "Miner", new Smurf("Nimble Smurf", "Miner", "Worker", 46) },
            { "Builder", new Smurf("Vanity Smurf", "Builder", "Worker", 76) },
            { "Harvester", new Smurf("Fisher Smurf", "Harvester", "Worker", 48) }
        };
        
        Dictionary<string, Smurf> actual = Smurf.OldestPerJob(smurfsList1);
        
        Assert.That(IsDictionaryEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList2()
    {
        List<Smurf> smurfsList2 = TestsData.smurfsList2;
        
        var expected = new Dictionary<string, Smurf>
        {
            { "Scribe", new Smurf("Wise Smurf", "Scribe", "Worker", 124) },
            { "Farmer", new Smurf("Mighty Smurf", "Farmer", "Worker", 105) },
            { "Cook", new Smurf("Happy Smurf", "Cook", "Captain", 42) },
            { "Miner", new Smurf("Dancer Smurf", "Miner", "Worker", 20) },
            { "Builder", new Smurf("Jolly Smurf", "Builder", "Worker", 78) },
            { "Harvester", new Smurf("Valiant Smurf", "Harvester", "Worker", 61) },
            { "Hunter", new Smurf("Thoughtful Smurf", "Hunter", "Worker", 21) }
        };
        
        Dictionary<string, Smurf> actual = Smurf.OldestPerJob(smurfsList2);
        
        Tools.PrintDictionary(actual);
        
        Assert.That(IsDictionaryEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList3()
    {
        List<Smurf> smurfsList3 = TestsData.smurfsList3;
        
        var expected = new Dictionary<string, Smurf>
        {
            { "Cook", new Smurf("Hearty Smurf", "Cook", "Worker", 36) },
            { "Gardener", new Smurf("Mellow Smurf", "Gardener", "Worker", 45) },
            { "Hunter", new Smurf("Lucky Smurf", "Hunter", "Worker", 32) },
            { "Sage", new Smurf("Wise Smurf", "Sage", "Captain", 88) },
            { "Entertainer", new Smurf("Jovial Smurf", "Entertainer", "Worker", 29) },
            { "Explorer", new Smurf("Eager Smurf", "Explorer", "Worker", 19) },
            { "Craftsman", new Smurf("Nifty Smurf", "Craftsman", "Worker", 57) },
            { "Philosopher", new Smurf("Sage Smurf", "Philosopher", "Worker", 65) },
            { "Runner", new Smurf("Zippy Smurf", "Runner", "Worker", 20) },
            { "Photographer", new Smurf("Snappy Smurf", "Photographer", "Worker", 30) },
            { "Thinker", new Smurf("Ponder Smurf", "Thinker", "Worker", 54) },
            { "Musician", new Smurf("Jolly Smurf", "Musician", "Worker", 40) },
            { "Singer", new Smurf("Gleeful Smurf", "Singer", "Worker", 22) },
            { "Dancer", new Smurf("Sprightly Smurf", "Dancer", "Worker", 26) },
            { "Athlete", new Smurf("Lively Smurf", "Athlete", "Worker", 18) },
            { "Farmer", new Smurf("Sunny Smurf", "Farmer", "Deputy Captain", 67) },
            { "Adventurer", new Smurf("Plucky Smurf", "Adventurer", "Deputy Captain", 31) },
            { "Builder", new Smurf("Chipper Smurf", "Builder", "Worker", 25) },
            { "Harvester", new Smurf("Peppy Smurf", "Harvester", "Worker", 43) },
        };
        
        Dictionary<string, Smurf> actual = Smurf.OldestPerJob(smurfsList3);
        
        Assert.That(IsDictionaryEqual(expected, actual));
    }

    [Test]
    public void TestEmptyList()
    {
        List<Smurf> smurfsList = new List<Smurf>();
        
        Dictionary<string, Smurf> expected = new Dictionary<string, Smurf>();
        Dictionary<string, Smurf> actual = Smurf.OldestPerJob(smurfsList);
        
        Assert.That(IsDictionaryEqual(expected, actual));
    }
}