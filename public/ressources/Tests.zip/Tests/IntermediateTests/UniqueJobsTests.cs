using WinterPreparation;

namespace Tests.IntermediateTests;

public class UniqueJobsTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestSampleList()
    {
        var smurfsList1 = TestsData.smurfsList1;

        var expected = new List<Smurf>() { };
        
        var actual = Smurf.UniqueJobs(smurfsList1);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList2()
    {
        var smurfsList2 = TestsData.smurfsList2;

        var expected = new List<Smurf>()
        {
            new Smurf("Dancer Smurf", "Miner", "Worker", 20),
            new Smurf("Thoughtful Smurf", "Hunter", "Worker", 21),
        };
        
        var actual = Smurf.UniqueJobs(smurfsList2);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
    [Test]
    public void TestSampleList3()
    {
        var smurfsList3 = TestsData.smurfsList3;

        var expected = new List<Smurf>()
        {
            new Smurf("Mellow Smurf", "Gardener", "Worker", 45),
            new Smurf("Lucky Smurf", "Hunter", "Worker", 32),
            new Smurf("Wise Smurf", "Sage", "Captain", 88),
            new Smurf("Jovial Smurf", "Entertainer", "Worker", 29),
            new Smurf("Eager Smurf", "Explorer", "Worker", 19),
            new Smurf("Nifty Smurf", "Craftsman", "Worker", 57),
            new Smurf("Sage Smurf", "Philosopher", "Worker", 65),
            new Smurf("Zippy Smurf", "Runner", "Worker", 20),
            new Smurf("Snappy Smurf", "Photographer", "Worker", 30),
            new Smurf("Ponder Smurf", "Thinker", "Worker", 54),
            new Smurf("Jolly Smurf", "Musician", "Worker", 40),
            new Smurf("Gleeful Smurf", "Singer", "Worker", 22),
            new Smurf("Sprightly Smurf", "Dancer", "Worker", 26),
            new Smurf("Lively Smurf", "Athlete", "Worker", 18),
            new Smurf("Sunny Smurf", "Farmer", "Deputy Captain", 67),
            new Smurf("Plucky Smurf", "Adventurer", "Deputy Captain", 31),
            new Smurf("Chipper Smurf", "Builder", "Worker", 25),
            new Smurf("Peppy Smurf", "Harvester", "Worker", 43)
        };
        
        var actual = Smurf.UniqueJobs(smurfsList3);
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }

    [Test]
    public void TestEmptyList()
    {
        var expected = new List<Smurf>() { };
        
        var actual = Smurf.UniqueJobs(new List<Smurf>());
        
        Assert.That(TestsData.IsSmurfListEqual(expected, actual));
    }
    
}