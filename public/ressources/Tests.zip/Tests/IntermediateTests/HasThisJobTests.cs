using WinterPreparation;

namespace Tests.IntermediateTests;

public class HasThisJobTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void TestSampleList1()
    {
        List<Smurf>[] smurfsArray = new List<Smurf>[]{TestsData.smurfsList1, TestsData.smurfsList2};

        List<Smurf>[] expected = new[]
        {
            TestsData.smurfsList1,
            TestsData.smurfsList2
        };
        
        var actual = Smurf.HasThisJob(smurfsArray, "Cook");
        
        Assert.That(actual, Is.EquivalentTo(expected));
    }
    
    [Test]
    public void TestSampleList2()
    {
        List<Smurf>[] smurfsArray = new List<Smurf>[]{TestsData.smurfsList1, TestsData.smurfsList2};

        List<Smurf>[] expected = new[]
        {
            TestsData.smurfsList2
        };
        
        var actual = Smurf.HasThisJob(smurfsArray, "Hunter");
        
        Assert.That(actual, Is.EquivalentTo(expected));
    }
    
    [Test]
    public void TestSampleList3()
    {
        List<Smurf>[] smurfsArray = new List<Smurf>[]{TestsData.smurfsList1, TestsData.smurfsList2};

        List<Smurf>[] expected = new List<Smurf>[] { };
        
        var actual = Smurf.HasThisJob(smurfsArray, "Teacher");
        
        Assert.That(actual, Is.EquivalentTo(expected));
    }
    
    [Test]
    public void TestSampleList4()
    {
        List<Smurf>[] smurfsArray = new List<Smurf>[]{TestsData.smurfsList1, TestsData.smurfsList2, TestsData.smurfsList3};

        List<Smurf>[] expected = new[]
        {
            TestsData.smurfsList2,
            TestsData.smurfsList3
        };
        
        var actual = Smurf.HasThisJob(smurfsArray, "Hunter");
        
        Assert.That(actual, Is.EquivalentTo(expected));
    }
    
    [Test]
    public void EmptyArray()
    {
        List<Smurf>[] smurfsArray = new List<Smurf>[] { };

        List<Smurf>[] expected = new List<Smurf>[] { };
        
        var actual = Smurf.HasThisJob(smurfsArray, "Hunter");
        
        Assert.That(actual, Is.EquivalentTo(expected));
    }
}