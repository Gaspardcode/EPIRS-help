using WinterPreparation;

namespace Tests.IntermediateTests;

public class AgePerRankTests
{
    [SetUp]
    public void Setup()
    {
    }
    
    public bool IsDictionaryEqual(Dictionary<string, double> actual, Dictionary<string, double> expected)
    {
        if (actual.Count != expected.Count)
        {
            return false;
        }

        foreach (var key in actual.Keys)
        {
            if (!expected.ContainsKey(key))
            {
                return false;
            }

            if (Math.Abs(actual[key] - expected[key]) > 0.1)
            {
                Console.WriteLine($"Expected: {expected[key]}, Actual: {actual[key]}");
                return false;
            }
        }

        return true;
    }

    [Test]
    public void TestSampleList1()
    {
        var smurfsList = TestsData.smurfsList1;
        var expected = new Dictionary<string, double>
        {
            { "Worker", 43.95 },
            { "Deputy Captain", 42 },
            { "Captain", 24 }
        };
        
        var actual = Smurf.AgePerRankDict(smurfsList);
        Assert.That(IsDictionaryEqual(actual, expected));
    }
    
    [Test]
    public void TestSampleList2()
    {
        var smurfsList = TestsData.smurfsList2;
        var expected = new Dictionary<string, double>
        {
            { "Worker", 49.18 },
            { "Deputy Captain", 30 },
            { "Captain", 42 }
        };
        
        var actual = Smurf.AgePerRankDict(smurfsList);
        Assert.That(IsDictionaryEqual(actual, expected));
    }
    
    [Test]
    public void TestSampleList3()
    {
        var smurfsList = TestsData.smurfsList3;
        var expected = new Dictionary<string, double>
        {
            { "Worker", 34.35 },
            { "Deputy Captain", 49 },
            { "Captain", 88 }
        };
        
        var actual = Smurf.AgePerRankDict(smurfsList);
        Assert.That(IsDictionaryEqual(actual, expected));
    }
    
    [Test]
    public void TestEmptyList()
    {
        var smurfsList = new List<Smurf>();
        var expected = new Dictionary<string, double>();
        
        var actual = Smurf.AgePerRankDict(smurfsList);
        Assert.That(actual, Is.EqualTo(expected));
    }
}