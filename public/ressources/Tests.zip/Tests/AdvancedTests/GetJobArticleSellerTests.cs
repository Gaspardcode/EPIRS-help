using WinterPreparation;

namespace Tests.AdvancedTests;

public class GetJobArticleSellerTests
{
    [SetUp]
    public void Setup()
    {
    }
    
    public bool IsDictionaryEquals(Dictionary<Smurf, double> expected, Dictionary<Smurf, double> actual)
    {
        if (expected.Count != actual.Count)
        {
            return false;
        }

        foreach (var kvp in expected)
        {
            Smurf key = kvp.Key;
            double value = kvp.Value;

            var matchingKey = actual.Keys.FirstOrDefault(k => TestsData.IsSmurfEqual(k, key));

            if (matchingKey == null)
            {
                return false;
            }

            double actualValue = actual[matchingKey];

            if (Math.Abs(value - actualValue) > 0.1)
            {
                return false;
            }
        }

        return true;
    }

    [Test]
    public void TestFirstMarket1()
    {
        Market market = TestsData.market1;
        string article = "Apples";

        var expected = new List<string>(){"Blacksmith", "Scriber", "Alchemist"};
        
        var actual = Market.GetJobArticleSeller(market, article);
        
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestFirstMarket2()
    {
        Market market = TestsData.market1;
        string article = "Potatoes";

        var expected = new List<string>(){"Blacksmith", "Alchemist"};
        
        var actual = Market.GetJobArticleSeller(market, article);
        
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void TestSecondMarket3()
    {
        Market market = TestsData.market2;
        string article = "Cake";

        var expected = new List<string>(){"Blacksmith", "Builder"};
        
        var actual = Market.GetJobArticleSeller(market, article);
        
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void NoArticle()
    {
        Market market = TestsData.market2;
        string article = "Apples";

        var expected = new List<string>(){};
        
        var actual = Market.GetJobArticleSeller(market, article);
        
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test]
    public void EmptyMarket()
    {
        Market market = TestsData.market3;
        string article = "Apples";

        var expected = new List<string>(){};
        
        var actual = Market.GetJobArticleSeller(market, article);
        
        Assert.That(actual, Is.EqualTo(expected));
    }
    
    
}