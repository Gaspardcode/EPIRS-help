using WinterPreparation;

namespace Tests.AdvancedTests;

public class GetNMostExpensiveTransactionSmurfTests
{
    [SetUp]
    public void Setup()
    {
    }
    
    public bool IsDictionaryEquals(Dictionary<Smurf, double> expected, Dictionary<Smurf, double> actual)
    {
        if (expected.Count != actual.Count)
        {
            return false;
        }

        foreach (var kvp in expected)
        {
            Smurf key = kvp.Key;
            double value = kvp.Value;

            var matchingKey = actual.Keys.FirstOrDefault(k => TestsData.IsSmurfEqual(k, key));

            if (matchingKey == null)
            {
                return false;
            }

            double actualValue = actual[matchingKey];

            if (Math.Abs(value - actualValue) > 0.1)
            {
                return false;
            }
        }

        return true;
    }

    [Test]
    public void TestFirstMarket1()
    {
        Market market = TestsData.market1;

        var expected = new Dictionary<Smurf, double>()
        {
            { new Smurf("Hefty Smurf", "Blacksmith", "Worker", 48), 42 },
        };
        
        var actual = Market.GetNMostExpensiveTransactionSmurf(market, 1);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
    
    [Test]
    public void TestFirstMarket2()
    {
        Market market = TestsData.market1;

        var expected = new Dictionary<Smurf, double>()
        {
            { new Smurf("Hefty Smurf", "Blacksmith", "Worker", 48), 42 },
            { new Smurf("Papa Smurf", "Alchemist", "Worker", 215), 26 },
            { new Smurf("Brainy Smurf", "Scriber", "Worker", 72), 14 }
        };
        
        var actual = Market.GetNMostExpensiveTransactionSmurf(market, 3);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
    
    [Test]
    public void TestSecondMarket1()
    {
        Market market = TestsData.market2;
        
        var expected = new Dictionary<Smurf, double>()
        {
            { new Smurf("Inventor Smurf", "Blacksmith", "Worker", 48), 42 },
            { new Smurf("Papa Smurf", "Alchemist", "Worker", 215), 26 },
            { new Smurf("Smurfette", "Farmer", "Worker", 26), 19 },
            { new Smurf("Clumsy Smurf", "Builder", "Worker", 16), 14 }
        };
        
        var actual = Market.GetNMostExpensiveTransactionSmurf(market, 4);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
    
    [Test]
    public void TestError()
    {
        Market market = TestsData.market2;

        Assert.Catch<ArgumentException>(() => Market.GetNMostExpensiveTransactionSmurf(market, 10));
    }
    
    [Test]
    public void TestEmptyMarket()
    {
        Market market = TestsData.market3;
        
        Assert.Catch<ArgumentException>(() => Market.GetNMostExpensiveTransactionSmurf(market, 1));
    }
}