using WinterPreparation;

namespace Tests.AdvancedTests;

public class GetSmurfYearBalanceTests
{
    [SetUp]
    public void Setup()
    {
    }
    
    public bool IsDictionaryEquals(Dictionary<string, double> expected, Dictionary<string, double> actual)
    {
        if (expected.Count != actual.Count)
        {
            return false;
        }

        foreach (var key in expected.Keys)
        {
            if (!actual.ContainsKey(key))
            {
                return false;
            }

            if (Math.Abs(expected[key] - actual[key]) > 0.1)
            {
                return false;
            }
        }

        return true;
    }

    [Test]
    public void TestFirstMarket1()
    {
        Market market = TestsData.market1;
        int year = 2019;

        var expected = new Dictionary<string, double>()
        {
            {"Papa Smurf", 45},
            {"Hefty Smurf", 42},
            {"Brainy Smurf", 9},
        };
        
        var actual = Market.GetSmurfYearBalance(market, year);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
    
    [Test]
    public void TestFirstMarket2()
    {
        Market market = TestsData.market1;
        int year = 2021;

        var expected = new Dictionary<string, double>()
        {
            {"Hefty Smurf", 20},
        };
        
        var actual = Market.GetSmurfYearBalance(market, year);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
    
    [Test]
    public void TestSecondMarket1()
    {
        Market market = TestsData.market2;
        int year = 2020;

        var expected = new Dictionary<string, double>()
        {
            {"Inventor Smurf", 5},
            {"Clumsy Smurf", 14},
            {"Papa Smurf", 4},
        };
        
        var actual = Market.GetSmurfYearBalance(market, year);
        
        Tools.PrintDictionary(actual);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
    
    [Test]
    public void TestWrongYear()
    {
        Market market = TestsData.market2;
        int year = 2050;

        var expected = new Dictionary<string, double>()
        {
        };
        
        var actual = Market.GetSmurfYearBalance(market, year);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
    
    [Test]
    public void TestEmptyMarket()
    {
        Market market = TestsData.market3;
        int year = 2020;

        var expected = new Dictionary<string, double>()
        {
        };
        
        var actual = Market.GetSmurfYearBalance(market, year);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
}