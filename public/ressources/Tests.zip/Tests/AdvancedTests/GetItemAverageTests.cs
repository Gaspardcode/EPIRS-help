using WinterPreparation;

namespace Tests.AdvancedTests;

public class GetItemAverageTests
{
    [SetUp]
    public void Setup()
    {
    }
    
    public bool IsDictionaryEquals(Dictionary<string, double> expected, Dictionary<string, double> actual)
    {
        if (expected.Count != actual.Count)
        {
            return false;
        }

        foreach (var key in expected.Keys)
        {
            if (!actual.ContainsKey(key))
            {
                return false;
            }

            if (Math.Abs(expected[key] - actual[key]) > 0.1)
            {
                return false;
            }
        }

        return true;
    }

    [Test]
    public void TestFirstMarket()
    {
        Market market = TestsData.market1;
        
        Dictionary<string, double> expected = new Dictionary<string, double>
        {
            { "Apples", 14.75 },
            { "Carrots", 10 },
            { "Potatoes", 17.5 },
        };
        
        Dictionary<string, double> actual = Market.GetItemAverage(market);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
    
    [Test]
    public void TestSecondMarket()
    {
        Market market = TestsData.market2;
        
        Dictionary<string, double> expected = new Dictionary<string, double>
        {
            { "Bread", 13 },
            { "Cake", 11 },
            { "Croissant", 24.33 },
        };
        
        Dictionary<string, double> actual = Market.GetItemAverage(market);
                
        Assert.That(IsDictionaryEquals(expected, actual));
    }

    [Test]
    public void TestEmptyMarket()
    {
        Market market = TestsData.market3;
        
        Dictionary<string, double> expected = new Dictionary<string, double>();
        
        Dictionary<string, double> actual = Market.GetItemAverage(market);
        
        Assert.That(IsDictionaryEquals(expected, actual));
    }
}